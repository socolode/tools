import sys
sys.path.append('/sd/apps/LightSketch/font')  # 添加字库路径
import proverbs_font8x16 as font_C  # 导入中文字库
 
import tft_config
import st7789
tft = tft_config.config(0)
tft.init()
 
tft.jpg('/sd/apps/LightSketch/main.jpg', 0, 0, st7789.SLOW)

import vga2_8x16 as font
import vga2_16x32 as font_16x32
from button_n import Button   # 导入按钮模块
from machine import Pin, PWM

# 和 tft_config 里一样，直接用 PWM 控制 Pin 11
backlight_PWM = PWM(Pin(11))
backlight_PWM.duty(300)  # 设置初始亮度值

import uos
import time
import gc
import ws2812
import machine

import network
import espnow
# 全局变量
sta = None
espnow_instance = None
receiver_mac = b'\xFF\xFF\xFF\xFF\xFF\xFF'

from machine import Pin
load_5v_en = Pin(40, Pin.OUT, Pin.PULL_UP)
load_12v_en = Pin(41, Pin.OUT, Pin.PULL_UP)
load_5v_en.value(0)
load_12v_en.value(0)

# 电压选择调试变量：0=5V，1=12V
voltage_mode = 0

config_file_path = '/sd/apps/config.json'

red_green_swap = False

def load_output_voltage():
    global voltage_mode, red_green_swap
    try:
        import ujson
        with open(config_file_path, 'r') as f:
            config = ujson.load(f)
            output_voltage = config.get('output_voltage', 5)
            if output_voltage == 12:
                voltage_mode = 1
            else:
                voltage_mode = 0
            print(f"输出电压设置: {output_voltage}V (voltage_mode={voltage_mode})")
            
            red_green_swap = config.get('red_green_swap', False)
            print(f"红绿切换设置: {red_green_swap}")
    except Exception as e:
        print(f"读取配置文件失败: {e}")
        voltage_mode = 0
        red_green_swap = False

load_output_voltage()

# 程序启动时默认关闭电压输出
load_5v_en.value(0)
load_12v_en.value(0)
print("电压输出默认关闭")

ws2812.init()  # 初始化

import sys
import select

poll = select.poll()
poll.register(sys.stdin, select.POLLIN)

# 定义最大分辨率
MAX_RESOLUTION = 480

from machine import Timer
import beep

elapsed_seconds = 0           # 计时变量
start_timer_flag = False  # 标志变量由主循环检测启动
rowCnt_buf = 0
VResolution_buf = 0

timer = Timer(-1)            # 定时器对象

def timer_callback(t):
    global elapsed_seconds
    elapsed_seconds = elapsed_seconds + 1 
    beep.tone(7000, 50)
        
   

    

 

# 定义按钮对象
buttons = Button()

def turn_off_ws2812():
    """将 WS2812 所有灯设为黑色（关闭）。"""
    black_buffer = bytearray([0, 0, 0] * MAX_RESOLUTION)
    ws2812.play_rgb_buffer(black_buffer, len(black_buffer), 0)
    print("WS2812 全黑关闭完成。")

white_buffer = bytearray([255, 255, 255] * MAX_RESOLUTION)
if red_green_swap:
    for i in range(0, len(white_buffer), 3):
        white_buffer[i+1], white_buffer[i+2] = white_buffer[i+2], white_buffer[i+1]

start_button_led_active = False
voltage_output_active = False  # 电压输出是否激活
stop_timer_start = 0  # 开始关闭计时的起始时间（0表示未开始计时）

def enable_voltage_output():
    """开启电压输出"""
    global voltage_output_active, voltage_mode
    if not voltage_output_active:
        if voltage_mode == 0:
            load_5v_en.value(1)
            load_12v_en.value(0)
            print("5V 输出已开启")
        else:
            load_5v_en.value(0)
            load_12v_en.value(1)
            print("12V 输出已开启")
        voltage_output_active = True

def disable_voltage_output():
    """关闭电压输出"""
    global voltage_output_active
    if voltage_output_active:
        load_5v_en.value(0)
        load_12v_en.value(0)
        print("电压输出已关闭")
        voltage_output_active = False

def check_start_button_for_led():
    """检测start按键状态，控制LED点亮和屏幕背光"""
    global start_button_led_active, fill_light_level
    
    start_pressed = buttons.get_button_state('start')
    
    if start_pressed and not start_button_led_active:
        enable_voltage_output()  # 先开启电压输出
        backlight_PWM.duty(1023)
        fill_light_brightness = fill_light_level / 10.0
        ws2812.play_rgb_buffer(white_buffer, len(white_buffer), fill_light_brightness)
        start_button_led_active = True
    elif not start_pressed and start_button_led_active:
        backlight_PWM.duty(300)
        turn_off_ws2812()
        start_button_led_active = False




# 检查是否存在 SD 卡
if 'sd' in uos.listdir('/'):
    if 'image' in uos.listdir('/sd'):
        screen_width = tft.width()
        screen_height = tft.height()

        image_dir_path = '/sd/image'
        image_dir_name = 'image'

        text_width = font.WIDTH * len(image_dir_name)
        start_x = 8

        bmp_files = [file for file in uos.listdir(image_dir_path) if file.endswith('.bmp')]

        start_y = font.HEIGHT + 10

        if len(bmp_files) > 5:
            files = bmp_files[:5]
        else:
            files = bmp_files

        selected_index = [0]
        current_file_index = [0]
        
brightness_level = 5  # 亮度等级 (1-10)，默认设置为5
speed_level = 5  # 速度等级 (1-10)，默认设置为5
sync_switch = 0  # 同步开关，0为关，1为开
selected_option = 'brightness'  # 默认选项为亮度
loop_same_image = 0  # 1 表示开，0 表示关
fill_light_level = 5  # 补光亮度等级 (1-10)，默认设置为5
previous_option = None  # 用于记录之前的选项




pointer_position = 0
previous_position = None  # 初始化前一个位置变量

start_delay = 0
remaining_time = 0
# 文件保存路径
save_file = '/sd/apps/LightSketch/values.txt'
# 从文件加载值
def load_values():
    global brightness_level, speed_level, start_delay, sync_switch, loop_same_image, fill_light_level
    print("tesst.")
    try:
        with open(save_file, 'r') as f:
            lines = f.readlines()
            brightness_level = float(lines[0].strip()) if len(lines) > 0 else 5.0
            speed_level = float(lines[1].strip()) if len(lines) > 1 else 5.0
            sync_switch = int(lines[2].strip()) if len(lines) > 2 else 0
            start_delay = int(lines[3].strip()) if len(lines) > 3 else 0
            print("tesst1")
            loop_same_image = int(lines[4].strip()) if len(lines) > 4 else 0
            print("tesst2")
            fill_light_level = int(lines[5].strip()) if len(lines) > 5 else 5
    except OSError:
        print("Save file not found, using default values.")
        brightness_level = 5.0
        speed_level = 5.0
        sync_switch = 0
        start_delay = 0
        loop_same_image = 0
        fill_light_level = 5


# 保存值到文件
def save_values():
    with open(save_file, 'w') as f:
        f.write(f"{brightness_level}\n")
        f.write(f"{speed_level}\n")
        f.write(f"{sync_switch}\n")
        f.write(f"{start_delay}\n")
        f.write(f"{loop_same_image}\n")
        f.write(f"{fill_light_level}\n")
        
    print("save_values")

def toggle_espnow():
    global espnow_instance, receiver_mac, sta, sync_switch
    
    if sync_switch == 1:  # 如果 sync_switch 为 1，初始化并激活 ESP-NOW
        if espnow_instance is None:  # 如果 ESP-NOW 尚未初始化
            # 初始化并激活
            sta = network.WLAN(network.STA_IF)  # 初始化 STA
            sta.active(True)  # 启动 STA 模式

            espnow_instance = espnow.ESPNow()  # 初始化 ESP-NOW
            espnow_instance.active(True)  # 打开 ESP-NOW
            espnow_instance.add_peer(receiver_mac)  # 添加接收端的 MAC 地址

            print("ESP-NOW 和 STA 模式已初始化并激活")
        else:
            # 如果 ESP-NOW 已初始化，则直接激活
            if not espnow_instance.active():  # 如果 ESP-NOW 还没有激活
                espnow_instance.active(True)  # 打开 ESP-NOW
                sta.active(True)  # 启动 STA 模式
                espnow_instance.add_peer(receiver_mac)  # 确保添加接收端的 MAC 地址
                print("ESP-NOW 和 STA 模式已重新激活")
    
    elif sync_switch == 0:  # 如果 sync_switch 为 0，关闭 ESP-NOW
        if espnow_instance and espnow_instance.active():  # 如果 ESP-NOW 已初始化并激活
            espnow_instance.active(False)  # 关闭 ESP-NOW
            if sta and sta.active():  # 确保 STA 已激活
                sta.active(False)  # 关闭 STA 模式
            print("ESP-NOW 和 STA 模式已关闭")



# 加载文件中的初始值
print("tesst0")
load_values()

toggle_espnow()


# 定义用于映射亮度等级到浮点值的函数
def map_brightness(level):
    return level * 0.1



def map_speed(level):
    return level  # 简单映射速度等级到整数值
    

# 绘制界面
def draw_interface():
    global previous_position,pointer_position,brightness_level,speed_level,start_delay,fill_light_level

    # 清除上一个圆点
    if previous_position is not None and previous_position != pointer_position:
        tft.fill_circle(14, 22 + previous_position * 22, 5, st7789.BLACK)

    # 更新选项显示
    for i in range(6):
        # 当前选中项加上小圆点
        if i == pointer_position:
            tft.fill_circle(14, 22 + i * 22, 5, st7789.RED)

        # 绘制更新的文本
        if i == 0:
            brightness_text = "{:<5}".format(f"{int(brightness_level * 10)} %") 
            tft.text(font, brightness_text, 67, 15 + i * 22, st7789.YELLOW, st7789.BLACK)
        elif i == 1:
            speed_text = "{:<5}".format(f"{int(speed_level * 10)} %") 
            tft.text(font, speed_text, 67, 15 + i * 22, st7789.YELLOW, st7789.BLACK)
        elif i == 2:
            if sync_switch == 0:
                sync_switch_text = "off"
            else:
                sync_switch_text = "on "
            tft.text(font, sync_switch_text, 67, 15 + i * 22, st7789.YELLOW, st7789.BLACK)
        elif i == 3:
            start_delay_text = "{:<6}".format(f"{start_delay} s") 
            tft.text(font, start_delay_text, 81, 15 + i * 22, st7789.YELLOW, st7789.BLACK)
        elif i == 4:
            loop_text = "on " if loop_same_image else "off"
            tft.text(font, loop_text, 67, 15 + i * 22, st7789.YELLOW, st7789.BLACK)
        elif i == 5:
            fill_light_text = "{:<5}".format(f"{fill_light_level}")
            tft.text(font, fill_light_text, 99, 15 + i * 22, st7789.YELLOW, st7789.BLACK)

    # 更新上一个指针位置
    previous_position = pointer_position



def refresh_file_list():
    current_y = start_y
    for index, file_name in enumerate(files):
        num_spaces = screen_width - len(file_name)
        padded_file_name = file_name + ' ' * num_spaces
        file_start_x = 5
        file_y = current_y
        text_color = st7789.BLACK
        if index == selected_index[0]:
            text_color = st7789.RED
            print("当前选中文件：", file_name)
            tft.fill_rect((tft.width() - 100) // 2, 125, 100, 100, st7789.BLACK)
            file_name_jpg = file_name.replace('.bmp', '.jpg')
            jpg_path = '/sd/image/' + file_name_jpg
            if file_name_jpg in uos.listdir(image_dir_path):
                try:
                    tft.jpg(jpg_path, (tft.width() - 100) // 2, 125, st7789.FAST)
                except Exception as e:
                    print("图片加载失败:", e)
                    tft.text(font, "jpg error", 30, 165, st7789.WHITE, st7789.BLACK)
            else:
                tft.text(font, "no.jpg", 45, 165, st7789.WHITE, st7789.BLACK)
        tft.text(font, padded_file_name, file_start_x, file_y, text_color, st7789.WHITE)
        current_y += font.HEIGHT
    gc.collect()

def on_start_button_short():
    pass

def on_up_button_short():
    global current_state, espnow_instance, sta,receiver_mac ,pointer_position
    
    if current_state == STATE_SET:
        if pointer_position > 0:
            pointer_position -= 1
            draw_interface()
    
    if current_state == STATE_IDLE:
        if selected_index[0] > 0:
            selected_index[0] -= 1
            current_file_index[0] -= 1
            refresh_file_list()
        elif selected_index[0] == 0:
            if current_file_index[0] != 0:
                current_file_index[0] -= 1
                files.pop()
                files.insert(0, bmp_files[current_file_index[0]])
                refresh_file_list()
            else:
                print("已到头")

def on_down_button_short():
    global current_state,pointer_position
    
    if current_state == STATE_SET:
        if pointer_position < 5:  # 六个选项
            pointer_position += 1
            draw_interface()
    
    if current_state == STATE_IDLE:
        if selected_index[0] < len(files) - 1:
            selected_index[0] += 1
            current_file_index[0] += 1
            refresh_file_list()
        elif selected_index[0] == len(files) - 1:
            if current_file_index[0] < len(bmp_files) - 1:
                current_file_index[0] += 1
                files.pop(0)
                files.append(bmp_files[current_file_index[0]])
                refresh_file_list()
            else:
                print("已添加所有图片文件")
    elif current_state == STATE_RUNNING or current_state == STATE_STOPPED:
        current_state = STATE_END


def on_center_button_action():
    global current_state, espnow_instance, receiver_mac, start_timer_flag
    if current_state == STATE_SET:
        current_state = STATE_IDLE
        tft.jpg('/sd/apps/LightSketch/main.jpg', 0, 0, st7789.SLOW)
        refresh_file_list()
    elif current_state == STATE_IDLE:
        current_state = STATE_START
    elif current_state == STATE_RUNNING:
        current_state = STATE_STOPPED
        timer.deinit()  # 暂停计时器
    elif current_state == STATE_STOPPED:
        current_state = STATE_RUNNING
        start_timer_flag = True  # 设置恢复定时器的标志

    # 仅当 ESP-NOW 功能启用时发送消息
    if espnow_instance and espnow_instance.active():
        try:
            espnow_instance.send(receiver_mac, "start_button_short", True)  # 发送消息
            print("消息已发送：start_button_short")
        except Exception as e:
            print(f"发送消息失败：{e}")


def on_center_button_exit():
    global current_state
    current_state = STATE_EXIT

def on_left_button_short():
    global pointer_position, brightness_level, speed_level, sync_switch, start_delay, brightness, loop_same_image, fill_light_level

    if current_state != STATE_SET or pointer_position == 3:
        return

    if pointer_position == 0:  # 调节亮度
        if brightness_level <= 1:
            brightness_level = max(0.1, brightness_level - 0.1)
        else:
            brightness_level = max(1, brightness_level - 1)
        brightness = map_brightness(brightness_level)
        print("当前亮度:", brightness)
    elif pointer_position == 1:  # 调节速度
        if speed_level <= 1:
            speed_level = max(0.1, speed_level - 0.1)
        else:
            speed_level = max(1, speed_level - 1)
    elif pointer_position == 2:  # 同步开关
        sync_switch = 1 - sync_switch  # 切换 0 和 1
        toggle_espnow()
    elif pointer_position == 3:  # 倒时延迟
        start_delay = max(0, start_delay - 1)
    elif pointer_position == 4:
        loop_same_image = 1 - loop_same_image  # 切换状态
    elif pointer_position == 5:  # 补光亮度
        fill_light_level = max(1, fill_light_level - 1)

    save_values()
    draw_interface()

def on_right_button_short():
    global pointer_position, brightness_level, speed_level, sync_switch, start_delay, brightness, loop_same_image, fill_light_level

    if current_state != STATE_SET or pointer_position == 3:
        return

    if pointer_position == 0:  # 调节亮度
        if brightness_level < 1:
            brightness_level = min(1, brightness_level + 0.1)
        else:
            brightness_level = min(10, brightness_level + 1)
        brightness = map_brightness(brightness_level)
        print("当前亮度:", brightness)
    elif pointer_position == 1:  # 调节速度
        if speed_level < 1:
            speed_level = min(1, speed_level + 0.1)
        else:
            speed_level = min(10, speed_level + 1)
    elif pointer_position == 2:  # 同步开关
        sync_switch = 1 - sync_switch  # 切换 0 和 1
        toggle_espnow()
    elif pointer_position == 3:  # 倒时延迟
        start_delay = min(1000, start_delay + 1)
    elif pointer_position == 4:
        loop_same_image = 1 - loop_same_image
    elif pointer_position == 5:  # 补光亮度
        fill_light_level = min(10, fill_light_level + 1)

    save_values()
    draw_interface()



def on_up_button_long():
    global current_state
    if current_state == STATE_IDLE:
        current_state = STATE_SET
        tft.jpg('/sd/apps/LightSketch/set.jpg', 0, 0, st7789.SLOW)
        draw_interface()

buttons.register_callback('start', 'short', on_start_button_short)
buttons.register_callback('center', 'short', on_center_button_action)
buttons.register_callback('left', 'short', on_left_button_short)
buttons.register_callback('right', 'short', on_right_button_short)
buttons.register_callback('up', 'short', on_up_button_short)
buttons.register_callback('up', 'long', on_up_button_long)
buttons.register_callback('down', 'short', on_down_button_short)
buttons.register_callback('center', 'long', on_center_button_exit)

# 自定义处理函数
def handle_message(host, msg):
    global current_state
    if current_state == STATE_IDLE:
        current_state = STATE_START
    elif current_state == STATE_RUNNING:
        current_state = STATE_STOPPED
    elif current_state == STATE_STOPPED:
        current_state = STATE_RUNNING


# 定义状态常量
STATE_INITIAL = 0
STATE_IDLE = 1
STATE_START = 2
STATE_RUNNING = 3
STATE_STOPPED = 4
STATE_END = 5
STATE_EXIT = 6
STATE_SET = 7

left_button_was_pressed = False
right_button_was_pressed = False

current_state = STATE_INITIAL
try:
    while True:
        # 处理电压输出逻辑：播放时开启，退出后3秒关闭
        # 播放状态定义：start按键按住、运行中或暂停状态
        currently_playing = start_button_led_active or (current_state == STATE_RUNNING) or (current_state == STATE_STOPPED)
        
        if currently_playing:
            # 正在播放，开启电压输出
            enable_voltage_output()
            stop_timer_start = 0  # 取消关闭倒计时
        elif voltage_output_active and not currently_playing:
            # 不在播放状态且电压已开启，开始3秒倒计时
            if stop_timer_start == 0:
                stop_timer_start = time.ticks_ms()  # 开始计时
            elif time.ticks_diff(time.ticks_ms(), stop_timer_start) > 3000:
                disable_voltage_output()  # 3秒后关闭
                stop_timer_start = 0  # 重置计时器
        
        if espnow_instance and espnow_instance.active():  # 确保 ESP-NOW 已激活
            if espnow_instance.any():  # 检查是否有消息
                host, msg = espnow_instance.recv()
                if msg:
                    handle_message(host, msg)  # 处理接收到的消息
        
        if current_state == STATE_INITIAL:
            print("程序处于初始状态。")
            check_start_button_for_led()

            tft.fill_rect(0, start_y, 135, 80, st7789.WHITE)
            refresh_file_list()          
            current_state = STATE_IDLE
            
        elif current_state == STATE_IDLE:
            check_start_button_for_led()
            events = poll.poll(0)
            if events:
                cmd = sys.stdin.readline().strip()
                if cmd.lower() == "start":
                    print("UART command received: start")
                    current_state = STATE_START
            time.sleep(0.01)

            
        elif current_state == STATE_START:
            machine.freq(240000000)  # 设置为最高频率 240 MHz
            
            tft.fill_rect(0, start_y, 135, 80, st7789.WHITE)
            tft.write(font_C, "中:续停", 5, 90, st7789.BLACK, st7789.WHITE)
            tft.write(font_C, "下:结束", 75, 90, st7789.BLACK, st7789.WHITE)

            f = open('/sd/image/' + files[selected_index[0]], "rb")

            f.seek(18)
            buff = f.read(4)
            HResolution = buff[3] * 1024 + buff[2] * 512 + buff[1] * 256 + buff[0]
            print("图片水平分辨率：", HResolution, "像素")
            if HResolution > MAX_RESOLUTION:
                HResolution = MAX_RESOLUTION

            f.seek(22)
            buff = f.read(4)
            VResolution = buff[3] * 1024 + buff[2] * 512 + buff[1] * 256 + buff[0]
            print("图片垂直分辨率：", VResolution, "像素")
            
             # 计算图片每行占用的字节数（向上往4的整数倍靠）
            if HResolution * 3 % 4 == 0:
                bytesPerRow = (HResolution * 3 // 4) * 4
            else:
                bytesPerRow = (HResolution * 3 // 4 + 1) * 4

            #bytesPerRow = calculate_bytes_per_row(HResolution)
            print("每行字节数（修正后）:", bytesPerRow)

            rowCnt = 0
            # 在状态转换前创建 buffer，避免在 STATE_RUNNING 循环内重复创建
            buffer = bytearray(bytesPerRow)  # 创建大小为 bytesPerRow 的缓冲区
            
            gc.collect()
            current_state = STATE_RUNNING
            remaining_time = start_delay
            
            brightness = map_brightness(brightness_level)
            print("当前亮度:", brightness)
            
            # 定义最大延迟时间
            T_max = 100  # 最大延迟 (ms)

            # 计算线性关系参数
            a = -T_max / (10 - 0.1)
            b = 10 * T_max / (10 - 0.1)

            # 计算延迟时间
            speed_level_val = (a * speed_level + b)/1000

            print(f"Speed Level: {speed_level}, Delay Time: {speed_level_val:.2f} s")

            
            start_time = time.ticks_us()
            
            elapsed_seconds = 0  # 初始化计时变量
            start_timer_flag = True

        elif current_state == STATE_RUNNING:
             
            # 如果 start_delay 不为 0，显示倒计时
            if remaining_time > 0:          
                start_delay_text = "{:<5}".format(remaining_time)  # 向右对齐
                tft.text(font_16x32, start_delay_text, 45, 40, st7789.BLUE, st7789.WHITE)
                remaining_time -= 1
                time.sleep(1)
            elif start_timer_flag:
                timer.init(period=1000, mode=Timer.PERIODIC, callback=timer_callback)
                start_timer_flag = False
                    
            elif rowCnt < VResolution-1:
                f.seek(bytesPerRow * rowCnt + 54)
                f.readinto(buffer)
                if red_green_swap:
                    for i in range(0, bytesPerRow, 3):
                        buffer[i+1], buffer[i+2] = buffer[i+2], buffer[i+1]
                ws2812.play_rgb_buffer(buffer, bytesPerRow, brightness)
                rowCnt += 1
                time.sleep(speed_level_val)  # 转换为秒
                rowCnt_buf = rowCnt
                VResolution_buf = VResolution
                tft.text(font_16x32, ws2812.calculate_percentage(rowCnt, VResolution, elapsed_seconds), 10, 40, st7789.BLACK, st7789.WHITE)
            else:
                if loop_same_image == 1:
                    rowCnt = 0
                    f.seek(0)
                    elapsed_seconds = 0
                    tft.text(font_16x32, "          ", 10, 40, st7789.BLACK, st7789.WHITE)
                    print("循环播放当前图片")
                else:
                    current_state = STATE_END

        elif current_state == STATE_SET:
            check_start_button_for_led()
            if pointer_position == 3:
                if buttons.get_button_state('left'):
                    start_delay = max(0, start_delay - 1)
                    left_button_was_pressed = True
                    draw_interface()
                elif left_button_was_pressed == True:
                    left_button_was_pressed = False
                    save_values()

                if buttons.get_button_state('right'):
                    start_delay = min(1000, start_delay + 1)
                    right_button_was_pressed = True
                    draw_interface()
                elif right_button_was_pressed == True:
                    right_button_was_pressed = False
                    save_values()
             
            time.sleep(0.1)    

        elif current_state == STATE_STOPPED:
            check_start_button_for_led()
            time.sleep(0.001)

        elif current_state == STATE_END:
            check_start_button_for_led()
            print("代码运行时长: {:.2f} 毫秒".format((time.ticks_us() - start_time) / 1000))
            timer.deinit()  # 暂停计时器
            machine.freq(160000000)  # 设置为最高频率 160 MHz
            rowCnt = 0
            current_state = STATE_INITIAL
            gc.collect()
            turn_off_ws2812()
            f.close()

        elif current_state == STATE_EXIT:
            check_start_button_for_led()
                   
            print("STATE_EXIT")           
            break
        
except MemoryError:
    print("Global MemoryError caught. Restarting...")
    machine.reset()
except KeyboardInterrupt:
    print("程序中断")
    if 'f' in locals() and f is not None:
        try:
            f.close()
            print("文件已成功关闭")
        except Exception as e:
            print("关闭文件时出错:", e)
    else:
        print("文件对象不存在或已经是 None，跳过关闭操作")      
    buffer = None
    if espnow_instance and espnow_instance.active():  # 确保 ESP-NOW 已激活
        espnow_instance.active(False)  # 关闭 ESP-NOW
        if sta and sta.active():  # 确保 sta 已初始化且激活
            sta.active(False)  # 关闭 STA 模式
        print("ESP-NOW 和 STA 模式已关闭")
    turn_off_ws2812()
    load_5v_en.value(0)
    load_12v_en.value(0)
    ws2812.deinit()    
    buttons.deinit()
    gc.collect()
finally:
    if 'f' in locals() and f is not None:
        try:
            f.close()
            print("文件已成功关闭")
        except Exception as e:
            print("关闭文件时出错:", e)
    else:
        print("文件对象不存在或已经是 None，跳过关闭操作")      
    buffer = None
    if espnow_instance and espnow_instance.active():  # 确保 ESP-NOW 已激活
        espnow_instance.active(False)  # 关闭 ESP-NOW
        if sta and sta.active():  # 确保 sta 已初始化且激活
            sta.active(False)  # 关闭 STA 模式
        print("ESP-NOW 和 STA 模式已关闭")
    turn_off_ws2812()
    load_5v_en.value(0)
    load_12v_en.value(0)
    ws2812.deinit()    
    buttons.deinit()
    timer.deinit()  # 暂停计时器
    gc.collect()










