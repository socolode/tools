from button_n import Button
from machine import Pin
import neopixel
import time
import gc

import tft_config
import st7789
tft = tft_config.config(0)
tft.init()
 
tft.jpg('/sd/apps/Palette/main.jpg', 0, 0, st7789.SLOW)

# 定义按钮对象
buttons = Button()

# 开启5V负载输出
load_5v_en = Pin(40, Pin.OUT, Pin.PULL_UP)
load_5v_en.value(0)  # 初始化为断电状态

# 开启12V负载输出
load_12v_en = Pin(41, Pin.OUT, Pin.PULL_UP)
load_12v_en.value(0)  # 初始化为断电状态

# 电压选择模式：0=5V，1=12V
voltage_mode = 0

# 红绿切换标记：False=正常（红=红，绿=绿），True=交换（红=绿，绿=红）
red_green_swap = False

# 定义最大分辨率
MAX_RESOLUTION = 144
try:
    import ujson
    with open('/sd/apps/config.json', 'r') as f:
        config = ujson.loads(f.read())
        light_stick_length = config.get('light_stick_length', 3)
        MAX_RESOLUTION = light_stick_length * 48
        print(f"Loaded light_stick_length: {light_stick_length}, MAX_RESOLUTION: {MAX_RESOLUTION}")
        
        # 读取输出电压配置
        output_voltage = config.get('output_voltage', 5)
        if output_voltage == 12:
            voltage_mode = 1
        else:
            voltage_mode = 0
        print(f"输出电压设置: {output_voltage}V (voltage_mode={voltage_mode})")
        
        # 读取红绿切换配置
        red_green_swap = config.get('red_green_swap', False)
        print(f"红绿切换设置: {red_green_swap}")
except Exception as e:
    print(f"Failed to load config, using default MAX_RESOLUTION=144: {e}")
    voltage_mode = 0
    red_green_swap = False

np = neopixel.NeoPixel(Pin(13), MAX_RESOLUTION)

# 程序启动时默认关闭电压输出
load_5v_en.value(0)
load_12v_en.value(0)
print("电压输出默认关闭")

interval_mode = False  # 默认开启间隔亮模式

brightness = 1  # 初始化亮度为2
color = 0
led_state = False  # 初始化LED状态为开
exit_program = False  # 退出标志位
voltage_output_active = False  # 电压输出是否激活
stop_timer_start = 0  # 开始关闭计时的起始时间（0表示未开始计时）

# 定义最小亮度因子，避免颜色完全变暗
MIN_BRIGHTNESS_FACTOR = 0.1

# 计算亮度因子
brightness_factor = max(brightness / 4, MIN_BRIGHTNESS_FACTOR)

# 定义颜色列表
colors = [
    0xF800,  # 红色
    0xFC00,  # 橙色
    0xFFE0,  # 黄色
    0x87E0,  # 浅绿
    0x07E0,  # 绿色
    0x07FF,  # 青色
    0x03FF,  # 天蓝
    0x001F,  # 蓝色
    0x780F,  # 紫色
    0xF81F,  # 粉色
    0x8410,  # 灰色
    0xFFFF,  # 白色
    0x8506,  # 彩色
    0x8523   # 彩色2
]

def enable_voltage_output():
    """开启电压输出"""
    global voltage_output_active, voltage_mode
    if not voltage_output_active:
        if voltage_mode == 0:
            load_5v_en.value(1)
            load_12v_en.value(0)
            print("5V 输出已开启")
        else:
            load_5v_en.value(0)
            load_12v_en.value(1)
            print("12V 输出已开启")
        voltage_output_active = True

def disable_voltage_output():
    """关闭电压输出"""
    global voltage_output_active
    if voltage_output_active:
        load_5v_en.value(0)
        load_12v_en.value(0)
        print("电压输出已关闭")
        voltage_output_active = False

def is_playing():
    """判断是否处于播放状态：LED开启 或 start按键按下"""
    return start_button_active or led_state

def get_color(color_index):
    """获取实际显示的颜色，支持红绿交换"""
    global red_green_swap
    
    if red_green_swap:
        if color_index == 0:
            return colors[4]
        elif color_index == 4:
            return colors[0]
        elif color_index == 3:
            return colors[0]
    
    return colors[color_index]

def apply_brightness(color, brightness):
    # 颜色分量
    r = (color >> 11) & 0x1F
    g = (color >> 5) & 0x3F
    b = color & 0x1F
    
    # 亮度因子
    factor = max(brightness / 4.0, 0.1)  # 确保最低亮度不为0
    
    if color == 0xFFFF:  # 如果颜色是白色
        # 计算原始RGB值
        r = int(31 * factor)  # 31是白色的最大红色值
        g = int(63 * factor)  # 63是白色的最大绿色值
        b = int(31 * factor)  # 31是白色的最大蓝色值
    else:
        r = int((r / 31.0) * factor * 31)
        g = int((g / 63.0) * factor * 63)
        b = int((b / 31.0) * factor * 31)
    
    # 确保颜色在有效范围内
    r = min(max(r, 0), 31)
    g = min(max(g, 0), 63)
    b = min(max(b, 0), 31)
    
    return (r << 11) | (g << 5) | b



def wheel(pos):
    """Generate rainbow colors across 0-255 positions."""
    if pos < 85:
        return (pos * 3, 255 - pos * 3, 0)
    elif pos < 170:
        pos -= 85
        return (255 - pos * 3, 0, pos * 3)
    else:
        pos -= 170
        return (0, pos * 3, 255 - pos * 3)

# 按钮回调函数
def left_button_short_press_callback():
    global brightness
    if brightness > 0:  
        brightness -= 1
        tft.fill_circle(41+(13*(brightness+1)), 25, 4, st7789.BLACK)
        tft.fill_circle(41+(13*brightness), 25, 4, st7789.WHITE)
 

def right_button_short_press_callback():
    global brightness
    if brightness < 4:  
        brightness += 1
        tft.fill_circle(41+(13*(brightness-1)), 25, 4, st7789.BLACK)
        tft.fill_circle(41+(13*brightness), 25, 4, st7789.WHITE)
    

def up_button_short_press_callback():
    global color
    clear_color_circle(color)
    
    color -= 1
    if color < 0:
        color = 13
    
    show_color_circle(color)
    update_center_circle(color)

def down_button_short_press_callback():
    global color
    clear_color_circle(color)
    
    color += 1
    if color > 13:
        color = 0
    
    show_color_circle(color)
    update_center_circle(color)
    
def up_button_long_press_callback():
    global interval_mode
    interval_mode = not interval_mode  # 切换间隔亮与否
    if interval_mode:
        print("间隔亮模式已开启")
    else:
        print("不间隔亮模式已开启")


def update_center_circle(color):
    center_x = tft.width() // 2
    center_y = (tft.height() // 2) - 30
    radius = 25

    if color == 12:  # 彩色
        rainbow_colors = [0xF800, 0xFC00, 0xFFE0, 0x87E0, 0x07E0, 0x07FF, 0x03FF, 0x001F]
        for i in range(len(rainbow_colors)):
            tft.fill_circle(center_x, center_y, int(radius * (0.8 ** i)), rainbow_colors[i])
    elif color == 13:  # 彩色2
        rainbow_colors = [0x001F, 0x03FF, 0x07FF, 0x07E0, 0x87E0, 0xFFE0, 0xFC00, 0xF800]
        for i in range(len(rainbow_colors)):
            tft.fill_circle(center_x, center_y, int(radius * (0.8 ** i)), rainbow_colors[i])
    else:
        tft.fill_circle(center_x, center_y, radius, colors[color])

def show_color_circle(color):
    if color <= 6:
        tft.fill_circle(25, 49 + (13 * color), 4, st7789.WHITE)
    else:
        tft.fill_circle(109, 49 + (13 * (color - 7)), 4, st7789.WHITE)

def clear_color_circle(color):
    if color <= 6:
        tft.fill_circle(25, 49 + (13 * color), 4, st7789.BLACK)
    else:
        tft.fill_circle(109, 49 + (13 * (color - 7)), 4, st7789.BLACK)

# 定义短按center按钮的回调函数
def center_button_short_press_callback():
    global led_state
    led_state = not led_state  # 切换LED的状态
       

# 定义长按center按钮的回调函数
def center_button_long_press_callback():
    global exit_program
    exit_program = True  # 设置退出标志位

# 注册按钮回调函数
buttons.register_callback('left', 'short', left_button_short_press_callback)
buttons.register_callback('right', 'short', right_button_short_press_callback)
buttons.register_callback('up', 'short', up_button_short_press_callback)
buttons.register_callback('up', 'long', up_button_long_press_callback)
buttons.register_callback('down', 'short', down_button_short_press_callback)
buttons.register_callback('center', 'short', center_button_short_press_callback)
buttons.register_callback('center', 'long', center_button_long_press_callback)

# 绘制初始的中心圆
tft.fill_circle(tft.width() // 2, (tft.height() // 2) - 30, 25, colors[0])
tft.fill_circle(41+(13*brightness), 25, 4, st7789.WHITE)
show_color_circle(color)

start_button_active = False  # start按键是否按下

# 预分配白色补光缓冲区（用于快速点亮）
white_buffer = bytearray([255, 255, 255] * MAX_RESOLUTION)
if red_green_swap:
    for i in range(0, len(white_buffer), 3):
        white_buffer[i+1], white_buffer[i+2] = white_buffer[i+2], white_buffer[i+1]

def turn_off_neopixel():
    np.fill((0, 0, 0))
    np.write()

def check_start_button_for_led():
    """检测start按键状态，快速点亮/熄灭LED（仅在led_state为False时生效）"""
    global start_button_active
    
    if led_state:
        if start_button_active:
            start_button_active = False
        return
    
    start_pressed = buttons.get_button_state('start')
    
    if start_pressed and not start_button_active:
        # 按下start：立即开启电压输出，立即点亮LED（显示当前选中颜色）
        start_button_active = True
        enable_voltage_output()
        # 根据当前选中的颜色点亮LED
        if color == 12:  # 彩色
            fixed_rainbow_colors = [
                (255, 0, 0), (255, 127, 0), (255, 255, 0),
                (0, 255, 0), (0, 0, 255), (75, 0, 130), (148, 0, 211)
            ]
            num_colors = len(fixed_rainbow_colors)
            for i in range(MAX_RESOLUTION):
                color_index = i * num_colors // MAX_RESOLUTION
                r, g, b = fixed_rainbow_colors[color_index]
                brightness_factor = max(brightness / 4, MIN_BRIGHTNESS_FACTOR)
                np[i] = (int(r * brightness_factor), int(g * brightness_factor), int(b * brightness_factor))
        elif color == 13:  # 彩色2（整体单色）
            r, g, b = wheel(0)
            brightness_factor = max(brightness / 4, MIN_BRIGHTNESS_FACTOR)
            adjusted_color = (int(r * brightness_factor), int(g * brightness_factor), int(b * brightness_factor))
            for i in range(MAX_RESOLUTION):
                np[i] = adjusted_color
        else:
            adjusted_color = apply_brightness(get_color(color), brightness)
            r = adjusted_color >> 11
            g = (adjusted_color >> 5) & 0x3F
            b = adjusted_color & 0x1F
            rgb = (int(r * 255 / 31), int(g * 255 / 63), int(b * 255 / 31))
            for i in range(MAX_RESOLUTION):
                np[i] = rgb
        np.write()
    elif not start_pressed and start_button_active:
        # 松开start：立即熄灭LED，电压输出延迟关闭（缓存时间）
        start_button_active = False
        turn_off_neopixel()

while not exit_program:
    # 快速点亮检测（轮询方式）
    check_start_button_for_led()
    
    # 处理电压输出逻辑：播放时开启，停止后3秒关闭
    currently_playing = start_button_active or led_state
    
    if currently_playing:
        enable_voltage_output()
        stop_timer_start = 0
    elif voltage_output_active and not currently_playing:
        if stop_timer_start == 0:
            stop_timer_start = time.ticks_ms()
        elif time.ticks_diff(time.ticks_ms(), stop_timer_start) > 3000:
            disable_voltage_output()
            stop_timer_start = 0
    
    # 正常LED光效（只有start没按下时才执行）
    if not start_button_active:
        if led_state:
            current_color = color

            if color == 12:  # 固定的彩虹色
                fixed_rainbow_colors = [
                    (255, 0, 0),      # 红色
                    (255, 127, 0),    # 橙色
                    (255, 255, 0),    # 黄色
                    (0, 255, 0),      # 绿色
                    (0, 0, 255),      # 蓝色
                    (75, 0, 130),     # 靛色
                    (148, 0, 211)     # 紫色
                ]
                
                num_colors = len(fixed_rainbow_colors)
                for i in range(MAX_RESOLUTION):
                    color_index = i * num_colors // MAX_RESOLUTION
                    r, g, b = fixed_rainbow_colors[color_index]
                    brightness_factor = max(brightness / 4, MIN_BRIGHTNESS_FACTOR)
                    adjusted_color = (int(r * brightness_factor), int(g * brightness_factor), int(b * brightness_factor))
                    
                    # 根据 interval_mode 来决定是否间隔亮
                    if interval_mode:
                        if i % 2 == 0:  # 偶数灯亮
                            np[i] = adjusted_color
                        else:           # 奇数灯灭
                            np[i] = (0, 0, 0)
                    else:
                        np[i] = adjusted_color  # 不间隔亮，全部亮
                np.write()
                time.sleep(0.1)

            elif color == 13:  # 整体渐变彩虹效果
                for i in range(256):
                    if color != current_color or not led_state or exit_program:
                        break
                    r, g, b = wheel(i & 255)
                    brightness_factor = max(brightness / 4, MIN_BRIGHTNESS_FACTOR)
                    adjusted_color = (int(r * brightness_factor), int(g * brightness_factor), int(b * brightness_factor))

                    # 根据 interval_mode 来决定是否间隔亮
                    for j in range(MAX_RESOLUTION):
                        if interval_mode:
                            if j % 2 == 0:  # 偶数灯亮
                                np[j] = adjusted_color
                            else:           # 奇数灯灭
                                np[j] = (0, 0, 0)
                        else:
                            np[j] = adjusted_color  # 不间隔亮，全部亮
                    np.write()
                    time.sleep(0.001)  # 渐变速度

            else:
                adjusted_color = apply_brightness(get_color(color), brightness)
                r = adjusted_color >> 11
                g = (adjusted_color >> 5) & 0x3F
                b = adjusted_color & 0x1F
                rgb = (int(r * 255 / 31), int(g * 255 / 63), int(b * 255 / 31))
                
                # 根据 interval_mode 来决定是否间隔亮
                for i in range(MAX_RESOLUTION):
                    if interval_mode:
                        if i % 2 == 0:  # 偶数灯亮
                            np[i] = rgb
                        else:           # 奇数灯灭
                            np[i] = (0, 0, 0)
                    else:
                        np[i] = rgb  # 不间隔亮，全部亮
                np.write()
                time.sleep(0.1)
        else:
            # led_state 为 False 且 start 没按下时才关闭LED
            np.fill((0, 0, 0))
            np.write()
            time.sleep(0.1)



# 清理操作，例如关闭LED或其他资源释放
np.fill((0, 0, 0))  # 确保LED关闭
np.write()
# 关闭所有电压输出
load_5v_en.value(0)
load_12v_en.value(0)
buttons.deinit()
tft.fill(st7789.BLACK)  # 清除屏幕
gc.collect()
